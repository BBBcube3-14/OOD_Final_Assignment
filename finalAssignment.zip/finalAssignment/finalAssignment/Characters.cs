﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;

namespace finalAssignment{
    internal class Character{

        int[] stars = { 
            0, 300, 450, 675, 1013, 1516, 2660, 4655
        };

        double[] xpGP = { 0,
          1.5,     3,   4.5,     6,   7.5,
            9,  10.5,    12,    15,    18,
           21,    24,    27,    30,    33,
           36,    39,    42,  46.5,    51, 
         55.5,    60,  64.5,    69,  73.5,
         79.5,  85.5,  91.5,  97.5, 103.5,
          111, 118.5,   126, 133.5, 142.5,
        151.5, 160.5, 169.5,   180, 190.5,
          201,   213,   225, 238.5,   252,
        265.5, 280.5, 295.5,   312, 328.5,
        346.5,   366, 385.5, 406.5,   429,
        451.5, 475.5,   501,   528, 556.5,
        586.5,   618,   651,   685, 721.5,
          759,   798,   840, 883.5, 928.5,
        976.5,  1028,  1080,  1136,  1194,
         1256,  1320,  1388,  1458,  1533,
         1613,  1697,  1785,  1878,  1976
        };

        double[,] gear = new double[,] {
            // 0      1     2       3    4      5
            {   0,    0,    0,      0,   0,    0}, //0
            {   0, 10.5,   21,   31.5,   42, 52.5},//1
            {  63,   96,  129,    162,  195,  228},//2
            { 261,  303,  345,    387,  429,  471},//3
            { 513,  569,  624,  679.5,  735,  790},//4
            { 846,  912,  978,   1044, 1110, 1176},//5
            {1242, 1326, 1410,   1494, 1578, 1662},//6
            {1746, 1859, 1971, 2083.5, 2196, 2309},//7
            {2421, 2543, 2664, 2785.5, 2907, 3029},//8
            {3150, 3293, 3435, 3577.5, 3720, 3863},//9
            {4005, 4182, 4359,   4536, 4713, 4890},//10
            {5067, 5265, 5463,   5661, 5859, 6057},//11
            {6255, 6465, 6675,   6885, 7095, 7305},//12
            {7515, 7515, 7515,   7515, 7515, 7515} //13
        };

        double[] abilities = {
            0, 0, 42, 97.5, 163.5, 276,
            397.5, 574.5, 784.5, 2981, 2981};

        double[] mods = {0, 180, 202.5, 225, 247.5, 271.5, 316.5};

        public string _name;
        public int _stars;
        public int _xp;
        public int _gear;
        public int _pieces;

        public string _basic;
        public string _lead;
        public string _specOne;
        public string _specTwo;
        public string _uniqOne;
        public string _uniqTwo;

        public string _square;
        public string _arrow;
        public string _diamond;
        public string _triangle;
        public string _circle;
        public string _plus;

        public double _cp = 0;

        public string Name {
            get { return this._name; }
            set{ this._name = value; } 
        }
        public int Stars { 
            get { return this._stars; } 
            set{  this._stars = value; } 
        }
        public int XP {
            get { return this._xp; }
            set { this._xp = value; }
        }
        public int Gear { 
            get { return this._gear; } 
            set{ this._gear = value; } 
        }
        public int Pieces { 
            get { return this._pieces; }
            set{ this._pieces = value; }
        }
        public string Basic { 
            get { return this._basic; } 
            set{ this._basic = value; } 
        }
        public string Lead { 
            get { return this._lead; }
            set{ this._lead = value; } 
        }
        public string SpecOne { 
            get { return this._specOne; }
            set{ this._specOne = value; } 
        }
        public string SpecTwo { 
            get { return this._specTwo; }
            set{ this._specTwo = value; }
        }
        public string UniqOne { 
            get { return this._uniqOne; }
            set{ this._uniqOne = value; }
        }
        public string UniqueTwo { 
            get { return this._uniqTwo; }
            set{ this._uniqTwo = value; }
        }
        public string Square { 
            get { return this._square; }
            set{ this._square = value; }
        }
        public string Arrow { 
            get { return this._arrow; }
            set{ this._arrow = value; }
        }
        public string Diamond { 
            get { return this._diamond; }
            set{ this._diamond = value; }
        }
        public string Triangle { 
            get { return this._triangle; }
            set{ this._triangle = value; }
        }
        public string Circle { 
            get { return this._circle; }
            set{ this._circle = value; }
        }
        public string Plus {
            get { return this._plus; }
            set{ this._plus = value; }
        }

        public decimal GP() {
            //=LOOKUP(Characters!$C20,Characters!$V$17:$V$102,Characters!$W$17:$W$102)+LOOKUP(Characters!$B20,Characters!$Y$17:$Y$24,Characters!$Z$17:$Z$24)+SUM(AN20:AZ20)
            //XP + Stars + Abilities + Gear + Mod
            
            double abilityTotal = 0;
            double modTotal = 0;
            if (_basic == "0" || _basic == "1") {
                abilityTotal += abilities[0];
            } else if (_basic == "2") {
                abilityTotal += abilities[2];
            } else if (_basic == "3") {
                abilityTotal += abilities[3];
            } else if (_basic == "4") {
                abilityTotal += abilities[4];
            } else if (_basic == "5") {
                abilityTotal += abilities[5];
            } else if (_basic == "6") {
                abilityTotal += abilities[6];
            } else if (_basic == "7") {
                abilityTotal += abilities[7];
            } else if (_basic == "O") {
                abilityTotal += abilities[8];
            } else if (_basic == "Z") {
                abilityTotal += abilities[9];
            } else if (_basic == "C") {
                abilityTotal += abilities[10];
            }

            if (_lead== "0" || _lead == "1") {
                abilityTotal += abilities[0];
            } else if (_lead == "2") {
                abilityTotal += abilities[2];
            } else if (_lead == "3") {
                abilityTotal += abilities[3];
            } else if (_lead == "4") {
                abilityTotal += abilities[4];
            } else if (_lead == "5") {
                abilityTotal += abilities[5];
            } else if (_lead == "6") {
                abilityTotal += abilities[6];
            } else if (_lead == "7") {
                abilityTotal += abilities[7];
            } else if (_lead == "O") {
                abilityTotal += abilities[8];
            } else if (_lead == "Z") {
                abilityTotal += abilities[9];
            } else if (_lead == "C") {
                abilityTotal += abilities[10];
            }

            if (_specOne == "0" || _specOne == "1") {
                abilityTotal += abilities[0];
            } else if (_specOne == "2") {
                abilityTotal += abilities[2];
            } else if (_specOne == "3") {
                abilityTotal += abilities[3];
            } else if (_specOne == "4") {
                abilityTotal += abilities[4];
            } else if (_specOne == "5") {
                abilityTotal += abilities[5];
            } else if (_specOne == "6") {
                abilityTotal += abilities[6];
            } else if (_specOne == "7") {
                abilityTotal += abilities[7];
            } else if (_specOne == "O") {
                abilityTotal += abilities[8];
            } else if (_specOne == "Z") {
                abilityTotal += abilities[9];
            } else if (_specOne == "C") {
                abilityTotal += abilities[10];
            }

            if (_specTwo == "0" || _specTwo == "1") {
                abilityTotal += abilities[0];
            } else if (_specTwo == "2") {
                abilityTotal += abilities[2];
            } else if (_specTwo == "3") {
                abilityTotal += abilities[3];
            } else if (_specTwo == "4") {
                abilityTotal += abilities[4];
            } else if (_specTwo == "5") {
                abilityTotal += abilities[5];
            } else if (_specTwo == "6") {
                abilityTotal += abilities[6];
            } else if (_specTwo == "7") {
                abilityTotal += abilities[7];
            } else if (_specTwo == "O") {
                abilityTotal += abilities[8];
            } else if (_specTwo == "Z") {
                abilityTotal += abilities[9];
            } else if (_specTwo == "C") {
                abilityTotal += abilities[10];
            }

            if (_uniqOne == "0" || _uniqOne == "1"){
                abilityTotal += abilities[0];
            } else if (_uniqOne == "2") {
                abilityTotal += abilities[2];
            } else if (_uniqOne == "3") {
                abilityTotal += abilities[3];
            } else if (_uniqOne == "4") {
                abilityTotal += abilities[4];
            } else if (_uniqOne == "5") {
                abilityTotal += abilities[5];
            } else if (_uniqOne == "6") {
                abilityTotal += abilities[6];
            } else if (_uniqOne == "7") {
                abilityTotal += abilities[7];
            } else if (_uniqOne == "O") {
                abilityTotal += abilities[8];
            } else if (_uniqOne == "Z") {
                abilityTotal += abilities[9];
            } else if (_uniqOne == "C") {
                abilityTotal += abilities[10];
            }

            if (_uniqTwo == "0" || _uniqTwo == "1") {
                abilityTotal += abilities[0];
            } else if (_uniqTwo == "2") {
                abilityTotal += abilities[2];
            } else if (_uniqTwo == "3") {
                abilityTotal += abilities[3];
            } else if (_uniqTwo == "4") {
                abilityTotal += abilities[4];
            } else if (_uniqTwo == "5") {
                abilityTotal += abilities[5];
            } else if (_uniqTwo == "6") {
                abilityTotal += abilities[6];
            } else if (_uniqTwo == "7") {
                abilityTotal += abilities[7];
            } else if (_uniqTwo == "O") {
                abilityTotal += abilities[8];
            } else if (_uniqTwo == "Z") {
                abilityTotal += abilities[9];
            } else if (_uniqTwo == "C") {
                abilityTotal += abilities[10];
            }

            if (_square == "Empty" || _square == "empty" || _square == "E" || _square == "e") {
                modTotal += mods[0];
            } else if (_square == "White" || _square == "white" || _square == "W" || _square == "w") {
                modTotal += mods[1];
            } else if(_square == "Green" || _square == "green" || _square == "G" || _square == "g") {
                modTotal += mods[2];
            } else if (_square == "Blue" || _square == "empty" || _square == "B" || _square == "b") {
                modTotal += mods[3];
            } else if (_square == "Purple" || _square == "purple" || _square == "P" || _square == "p") {
                modTotal += mods[4];
            } else if (_square == "Yellow" || _square == "yellow" || _square == "Y" || _square == "y") {
                modTotal += mods[0];
            } else if (_square == "6-Dot" || _square == "6") {
                modTotal += mods[0];
            }


            if (_diamond == "Empty" || _diamond == "empty" || _diamond == "E" || _diamond == "e") {
                modTotal += mods[0];
            } else if (_diamond == "White" || _diamond == "white" || _diamond == "W" || _diamond == "w") {
                modTotal += mods[1];
            } else if (_diamond == "Green" || _diamond == "green" || _diamond == "G" || _diamond == "g") {
                modTotal += mods[2];
            } else if (_diamond == "Blue" || _diamond == "empty" || _diamond == "B" || _diamond == "b") {
                modTotal += mods[3];
            } else if (_diamond == "Purple" || _diamond == "purple" || _diamond == "P" || _diamond == "p") {
                modTotal += mods[4];
            } else if (_diamond == "Yellow" || _diamond == "yellow" || _diamond == "Y" || _diamond == "y") {
                modTotal += mods[0];
            } else if (_diamond == "6-Dot" || _diamond == "6") {
                modTotal += mods[0];
            }

            if (_triangle == "Empty" || _triangle == "empty" || _triangle == "E" || _triangle == "e") {
                modTotal += mods[0];
            } else if (_triangle == "White" || _triangle == "white" || _triangle == "W" || _triangle == "w") {
                modTotal += mods[1];
            } else if (_triangle == "Green" || _triangle == "green" || _triangle == "G" || _triangle == "g") {
                modTotal += mods[2];
            } else if (_triangle == "Blue" || _triangle == "empty" || _triangle == "B" || _triangle == "b") {
                modTotal += mods[3];
            } else if (_triangle == "Purple" || _triangle == "purple" || _triangle == "P" || _triangle == "p") {
                modTotal += mods[4];
            } else if (_triangle == "Yellow" || _triangle == "yellow" || _triangle == "Y" || _triangle == "y") {
                modTotal += mods[0];
            } else if (_triangle == "6-Dot" || _triangle == "6") {
                modTotal += mods[0];
            }

            if (_circle == "Empty" || _circle == "empty" || _circle == "E" || _circle == "e") {
                modTotal += mods[0];
            } else if (_circle == "White" || _circle == "white" || _circle == "W" || _circle == "w") {
                modTotal += mods[1];
            } else if (_circle == "Green" || _circle == "green" || _circle == "G" || _circle == "g") {
                modTotal += mods[2];
            } else if (_circle == "Blue" || _circle == "empty" || _circle == "B" || _circle == "b") {
                modTotal += mods[3];
            } else if (_circle == "Purple" || _circle == "purple" || _circle == "P" || _circle == "p") {
                modTotal += mods[4];
            } else if (_circle == "Yellow" || _circle == "yellow" || _circle == "Y" || _circle == "y") {
                modTotal += mods[0];
            } else if (_circle == "6-Dot" || _circle == "6") {
                modTotal += mods[0];
            }

            if (_plus == "Empty" || _plus == "empty" || _plus == "E" || _plus == "e") {
                modTotal += mods[0];
            } else if (_plus == "White" || _plus == "white" || _plus == "W" || _plus == "w") {
                modTotal += mods[1];
            } else if (_plus == "Green" || _plus == "green" || _plus == "G" || _plus == "g") {
                modTotal += mods[2];
            } else if (_plus == "Blue" || _plus == "empty" || _plus == "B" || _plus == "b") {
                modTotal += mods[3];
            } else if (_plus == "Purple" || _plus == "purple" || _plus == "P" || _plus == "p") {
                modTotal += mods[4];
            } else if (_plus == "Yellow" || _plus == "yellow" || _plus == "Y" || _plus == "y") {
                modTotal += mods[0];
            } else if (_plus == "6-Dot" || _plus == "6") {
                modTotal += mods[0];
            }

            if (_arrow == "Empty" || _arrow == "empty" || _arrow == "E" || _arrow == "e") {
                modTotal += mods[0];
            } else if (_arrow == "White" || _arrow == "white" || _arrow == "W" || _arrow == "w") {
                modTotal += mods[1];
            } else if (_arrow == "Green" || _arrow == "green" || _arrow == "G" || _arrow == "g") {
                modTotal += mods[2];
            } else if (_arrow == "Blue" || _arrow == "empty" || _arrow == "B" || _arrow == "b") {
                modTotal += mods[3];
            } else if (_arrow == "Purple" || _arrow == "purple" || _arrow == "P" || _arrow == "p") {
                modTotal += mods[4];
            } else if (_arrow == "Yellow" || _arrow == "yellow" || _arrow == "Y" || _arrow == "y") {
                modTotal += mods[0];
            } else if (_arrow == "6-Dot" || _arrow == "6") {                modTotal += mods[0];
            }

            this._cp = xpGP[_xp] + stars[_stars] + gear[_gear, _pieces] + abilityTotal + modTotal;
            /*double[] mods = {
            0, 
            180, 
            202.5, 
            225, 
            247.5, 
            271.5, 
            316.5
        };*/
            return 0;
        }
        public Character() {
            _name = String.Empty;
            _stars = 0;
            _xp = 0;
            _gear = 0;
            _pieces = 0;

            _basic = "0";
            _lead = "0";
            _specOne = "0";
            _specTwo = "0";
            _uniqOne = "0";
            _uniqTwo = "0";

            _square = "Empty";
            _arrow = "Empty";
            _diamond = "Empty";
            _triangle = "Empty";
            _circle = "Empty";
            _plus = "Empty";
        }
        public void printBasicInfo() {
            Console.WriteLine("Name: " + _name + " * " + _stars + " XP " + _xp + " Gear " + _gear + " CP " + _cp);
        }
        public Character( String name, int stars, int xp, int gear, int pieces, String basic, String lead, String SO, String ST, String UO, String UT, String S, String A, String D, String T, String C, String P) {
            Name = name;
            Stars = stars;
            XP = xp;
            Gear = gear;
            Pieces = pieces;
            
            Basic = basic;
            Lead = lead;
            SpecOne = SO;
            SpecTwo = ST;
            UniqOne = UO;
            UniqueTwo = UT;

            Square = S;
            Arrow = A;
            Diamond = D; 
            Triangle = T;
            Circle = C;
            Plus = P;
        }
        public object Clone() {
            return this.MemberwiseClone();
        }
    }
}
