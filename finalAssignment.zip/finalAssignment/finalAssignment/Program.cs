﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finalAssignment {
    internal class Program {
        static void Main(string[] args) {
            Character[] character = new Character[300];
            Squad[] squad = new Squad[20];
            Ship[] ships = new Ship[100];
            Fleet[] fleets = new Fleet[10];

            int numberOfCharacters = 0;
            int numberOfSquad = 0;
            int numberOfShips = 0;
            int numberOfFleets = 0;
            int input = 10;
            do {
                Console.WriteLine("1. Add Character");
                Console.WriteLine("2. Add Ship");
                Console.WriteLine("3. Add Squad");
                Console.WriteLine("4. Add Fleet");
                Console.WriteLine("0. Quit");
                input = Convert.ToInt32(Console.ReadLine());
                if (input == 1) {
                    character[numberOfCharacters] = new Character();

                    Console.WriteLine("Enter a character name: ");
                    character[numberOfCharacters].Name = Console.ReadLine();
                    Console.WriteLine("Enter the XP level: ");
                    character[numberOfCharacters].XP = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the star levels: ");
                    character[numberOfCharacters].Stars = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the gear level: ");
                    character[numberOfCharacters].Gear = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the pieces: ");
                    character[numberOfCharacters].Pieces = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the basic ability level: ");
                    character[numberOfCharacters].Basic = Console.ReadLine();
                    Console.WriteLine("Enter the leader ability level: ");
                    character[numberOfCharacters].Lead = Console.ReadLine();
                    Console.WriteLine("Enter the first spcial ability level: ");
                    character[numberOfCharacters].SpecOne = Console.ReadLine();
                    Console.WriteLine("Enter the second special ability level: ");
                    character[numberOfCharacters].SpecTwo = Console.ReadLine();
                    Console.WriteLine("Enter the first uniquie ability level: ");
                    character[numberOfCharacters].UniqOne = Console.ReadLine();
                    Console.WriteLine("Enter the second unique ability level: ");
                    character[numberOfCharacters].UniqueTwo = Console.ReadLine();
                    Console.WriteLine("Enter the square mod color: ");
                    character[numberOfCharacters].Square = Console.ReadLine();
                    Console.WriteLine("Enter the arrow mod color: ");
                    character[numberOfCharacters].Arrow = Console.ReadLine();
                    Console.WriteLine("Enter the diamond mod color: ");
                    character[numberOfCharacters].Diamond = Console.ReadLine();
                    Console.WriteLine("Enter the triangle mod color: ");
                    character[numberOfCharacters].Triangle = Console.ReadLine();
                    Console.WriteLine("Enter the circle mod color: ");
                    character[numberOfCharacters].Circle = Console.ReadLine();
                    Console.WriteLine("Enter the plus mod color: ");
                    character[numberOfCharacters].Plus = Console.ReadLine();

                    character[numberOfCharacters].GP();
                    character[numberOfCharacters].printBasicInfo();
                    numberOfCharacters++;
                } else if (input == 2) {
                    ships[numberOfShips] = new Ship();
                    Console.WriteLine("Enter the ship name: ");
                    ships[numberOfShips].Name = Console.ReadLine();
                    Console.WriteLine("Enter the number of stars: ");
                    ships[numberOfShips].Stars = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the ship's xp level: ");
                    ships[numberOfShips].XP = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the pilot's name: ");
                    string pilotName = Console.ReadLine();
                    for (int i = 0; i < numberOfCharacters; i++) {
                        if (character[i]._name == pilotName) {
                            ships[numberOfShips]._pilot = new
                                Character(character[i]._name, character[i]._stars, character[i]._xp, character[i]._gear, character[i]._pieces, character[i]._basic, character[i]._lead,
                                character[i]._specOne, character[i]._specTwo, character[i]._uniqOne, character[i]._uniqTwo, character[i]._square, character[i]._arrow, character[i]._diamond,
                                character[i]._triangle, character[i]._circle, character[i]._plus);

                        }
                    }
                            
                    ships[numberOfShips].printShipInfo();
                    numberOfShips++;

                } else if (input == 3) {
                    squad[numberOfSquad] = new Squad();
                    Console.WriteLine("Enter the leader's name: ");
                    string leadName = Console.ReadLine();
                    for (int i = 0; i < numberOfCharacters; i++) {
                        if (character[i]._name == leadName) {
                            squad[numberOfSquad]._lead = new 
                                Character(character[i]._name, character[i]._stars, character[i]._xp, character[i]._gear, character[i]._pieces, character[i]._basic, character[i]._lead, 
                                character[i]._specOne, character[i]._specTwo, character[i]._uniqOne, character[i]._uniqTwo, character[i]._square, character[i]._arrow, character[i]._diamond, 
                                character[i]._triangle, character[i]._circle, character[i]._plus);
                            //(Character) character[i].Clone();
                            squad[numberOfSquad]._lead._cp = Convert.ToDouble(character[i].GP());
                            squad[numberOfSquad]._lead.printBasicInfo();
                        }
                    }                    
                    Console.WriteLine("Enter the second's name: ");
                    string second = Console.ReadLine();
                    for (int i = 0; i < numberOfCharacters; i++) {
                        if (character[i]._name == second) {
                            squad[numberOfSquad]._SIC = new Character(character[i]._name, character[i]._stars, character[i]._xp, character[i]._gear, character[i]._pieces, character[i]._basic, character[i]._lead,
                                character[i]._specOne, character[i]._specTwo, character[i]._uniqOne, character[i]._uniqTwo, character[i]._square, character[i]._arrow, character[i]._diamond, character[i]._triangle, character[i]._circle, character[i]._plus);
                            squad[numberOfSquad]._SIC._cp = Convert.ToDouble(character[i].GP());
                            squad[numberOfSquad]._SIC.printBasicInfo();
                        }
                    }
                    Console.WriteLine("Enter the third's name: ");
                    string third = Console.ReadLine();
                    for (int i = 0; i < numberOfCharacters; i++) {
                        if (character[i]._name == third) {
                            squad[numberOfSquad]._PT = new
                                Character(character[i]._name, character[i]._stars, character[i]._xp, character[i]._gear, character[i]._pieces, character[i]._basic, character[i]._lead,
                                character[i]._specOne, character[i]._specTwo, character[i]._uniqOne, character[i]._uniqTwo, character[i]._square, character[i]._arrow, character[i]._diamond,
                                character[i]._triangle, character[i]._circle, character[i]._plus);
                            squad[numberOfSquad]._PT._cp = Convert.ToDouble(character[i].GP());
                            squad[numberOfSquad]._PT.printBasicInfo();
                        }
                    }
                    
                    Console.WriteLine("Enter the fourth's name: ");
                    string fourth = Console.ReadLine();
                    for (int i = 0; i < numberOfCharacters; i++) {
                        Console.WriteLine(" character [" + i + "] name: " + character[i]._name + " fourth: " + fourth);
                        if (character[i]._name == fourth) {
                            squad[numberOfSquad]._Four = new
                                Character(character[i]._name, character[i]._stars, character[i]._xp, character[i]._gear, character[i]._pieces, character[i]._basic, character[i]._lead,
                                character[i]._specOne, character[i]._specTwo, character[i]._uniqOne, character[i]._uniqTwo, character[i]._square, character[i]._arrow, character[i]._diamond,
                                character[i]._triangle, character[i]._circle, character[i]._plus);
                            squad[numberOfSquad]._Four._cp = Convert.ToDouble(character[i].GP());
                            squad[numberOfSquad]._Four.printBasicInfo();
                        }
                    }
                    
                    Console.WriteLine("Enter the fifth's name: ");
                    string fifth = Console.ReadLine();
                    for (int i = 0; i < numberOfCharacters; i++) {
                        if (character[i]._name == fifth) {
                            squad[numberOfSquad]._FMB = new
                                Character(character[i]._name, character[i]._stars, character[i]._xp, character[i]._gear, character[i]._pieces, character[i]._basic, character[i]._lead,
                                character[i]._specOne, character[i]._specTwo, character[i]._uniqOne, character[i]._uniqTwo, character[i]._square, character[i]._arrow, character[i]._diamond,
                                character[i]._triangle, character[i]._circle, character[i]._plus);
                            squad[numberOfSquad]._FMB._cp = Convert.ToDouble(character[i].GP());
                            squad[numberOfSquad]._FMB.printBasicInfo();
                        }
                    }
                    squad[numberOfSquad].printSquad();
                    double sp = squad[numberOfSquad].SP();
                    Console.WriteLine("Squad Power: " + sp);
                    numberOfSquad++;
                } else if (input == 4) {
                    fleets[numberOfFleets] = new Fleet();
                    Console.WriteLine("Enter the capital ship's name: ");
                    string leadName = Console.ReadLine();
                    for (int i = 0; i < numberOfShips; i++){
                        if (ships[i]._shipName == leadName){
                            fleets[numberOfFleets]._capitalShip = new Ship(ships[i]._shipName, ships[i]._stars, ships[i]._xp, ships[i]._basic, ships[i]._special, ships[i]._ultimate);
                            fleets[numberOfFleets]._capitalShip._sp = Convert.ToDouble(ships[i].GP());
                            fleets[numberOfFleets]._capitalShip.printShipInfo();
                        }
                    }
                    Console.WriteLine("Enter the first starting ship's name: ");
                    string startOne = Console.ReadLine();
                    for (int i = 0; i < numberOfShips; i++) {
                        if (ships[i]._shipName == startOne) {
                            fleets[numberOfFleets]._startingOne = new Ship(ships[i]._shipName, ships[i]._stars, ships[i]._xp, ships[i]._basic, ships[i]._special, ships[i]._ultimate);
                            fleets[numberOfFleets]._startingOne._sp = Convert.ToDouble(ships[i].GP());
                            fleets[numberOfFleets]._startingOne.printShipInfo();
                        }
                    }
                    Console.WriteLine("Enter the second starting ship's name: ");
                    string startTwo = Console.ReadLine();
                    for (int i = 0; i < numberOfShips; i++) {
                        if (ships[i]._shipName == startTwo) {
                            fleets[numberOfFleets]._startingTwo = new Ship(ships[i]._shipName, ships[i]._stars, ships[i]._xp, ships[i]._basic, ships[i]._special, ships[i]._ultimate);
                            fleets[numberOfFleets]._startingTwo._sp = Convert.ToDouble(ships[i].GP());
                            fleets[numberOfFleets]._startingTwo.printShipInfo();
                        }
                    }
                    Console.WriteLine("Enter the third stating ship's name: ");
                    string startThree = Console.ReadLine();
                    for (int i = 0; i < numberOfShips; i++) {
                        if (ships[i]._shipName == startThree) {
                            fleets[numberOfFleets]._startingThree = new Ship(ships[i]._shipName, ships[i]._stars, ships[i]._xp, ships[i]._basic, ships[i]._special, ships[i]._ultimate);
                            fleets[numberOfFleets]._startingThree._sp = Convert.ToDouble(ships[i].GP());
                            fleets[numberOfFleets]._startingThree.printShipInfo();
                        }
                    }
                    Console.WriteLine("Enter the first reinforcement name: ");
                    string rOne = Console.ReadLine();
                    for (int i = 0; i < numberOfShips; i++) {
                        if (ships[i]._shipName == rOne) {
                            fleets[numberOfFleets]._reinforcementOne = new Ship(ships[i]._shipName, ships[i]._stars, ships[i]._xp, ships[i]._basic, ships[i]._special, ships[i]._ultimate);
                            fleets[numberOfFleets]._reinforcementOne._sp = Convert.ToDouble(ships[i].GP());
                            fleets[numberOfFleets]._reinforcementOne.printShipInfo();
                        }
                    }
                    Console.WriteLine("Enter the second reinforcement name: ");
                    string rTwo = Console.ReadLine();
                    for (int i = 0; i < numberOfShips; i++) {
                        if (ships[i]._shipName == rOne) {
                            fleets[numberOfFleets]._reinforcementTwo = new Ship(ships[i]._shipName, ships[i]._stars, ships[i]._xp, ships[i]._basic, ships[i]._special, ships[i]._ultimate);
                            fleets[numberOfFleets]._reinforcementTwo._sp = Convert.ToDouble(ships[i].GP());
                            fleets[numberOfFleets]._reinforcementTwo.printShipInfo();
                        }
                    }
                    Console.WriteLine("Enter the third reinforcement name: ");
                    string rThree = Console.ReadLine();
                    for (int i = 0; i < numberOfShips; i++)
                    {
                        if (ships[i]._shipName == rThree)
                        {
                            fleets[numberOfFleets]._reinforcementThree = new Ship(ships[i]._shipName, ships[i]._stars, ships[i]._xp, ships[i]._basic, ships[i]._special, ships[i]._ultimate);
                            fleets[numberOfFleets]._reinforcementThree._sp = Convert.ToDouble(ships[i].GP());
                            fleets[numberOfFleets]._reinforcementThree.printShipInfo();
                        }
                    }
                    Console.WriteLine("Enter the first reinforcement name: ");
                    string rFour = Console.ReadLine();
                    for (int i = 0; i < numberOfShips; i++) {
                        if (ships[i]._shipName == rFour) {
                            fleets[numberOfFleets]._reinforcementFour = new Ship(ships[i]._shipName, ships[i]._stars, ships[i]._xp, ships[i]._basic, ships[i]._special, ships[i]._ultimate);
                            fleets[numberOfFleets]._reinforcementFour._sp = Convert.ToDouble(ships[i].GP());
                            fleets[numberOfFleets]._reinforcementFour.printShipInfo();
                        }
                    }
                    fleets[numberOfFleets].printFleet();
                    numberOfFleets++;
                }

            } while (input != 0);
        }
    }
}
