﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.XPath;

namespace finalAssignment
{
    internal class Ship
    {
        public string _shipName;
        public int _stars;
        public int _xp;
        public string _basic;
        public string _special;
        public string _ultimate;
        public double _sp;
        public Character _pilot;

        public string Name {
            get { return this._shipName; }
            set { this._shipName = value; }
        }
        public int Stars {
            get { return this._stars; }
            set { this._stars = value; }
        }
        public int XP {
            get { return this._xp; }
            set { this._xp = value; }
        }
        public string Basic {
            get { return this._basic; }
            set { this._basic = value; }

        }
        public string Special {
            get { return this._special; }
            set { this._special = value; }
        }
        public string Ultimate {
            get { return this._ultimate; }
            set { this._ultimate = value; }
        }

        public double GP() {
            double[,] gear = new double[,] {
            // 0      1     2       3    4      5
            {   0,    0,    0,      0,   0,    0}, //0
            {   0,  7,   14,   21,   28, 35},//1
            {  42,   64,  86,    108,  130,  152},//2
            { 174,  202,  230, 258, 286,  314},//3
            { 342,  379, 416,  453, 490, 527},//4
            { 564, 608, 652, 696, 740, 784},//5
            {828, 884, 940, 996, 1052, 1108},//6
            {1164, 1239, 1314, 1389, 1464, 1539},//7
            {1614, 1695, 1776, 1857, 1938, 2019},//8
            {2100, 2195, 2290, 2385, 2480, 2575},//9
            {2670, 2788, 2906, 3024, 3142, 3260},//10
            {3378, 3510, 3642, 3774, 3906, 4038},//11
            {4170, 4310, 4450, 4590, 4730, 4870},//12
            {5010, 5010, 5010, 5010, 5010, 5010} //13
            };


            //double pilotContribution = 0;

            if (_pilot._xp == 85) {
                this._sp += 1317;
            } else if (_pilot._xp >= 80) {
                this._sp += 1022;
            } else if (_pilot._xp >= 70) {
                this._sp += 619;
            } else if (_pilot._xp >= 60) {
                this._sp += 371;
            } else if (_pilot._xp >= 50) {
                this._sp += 219;
            } else if (_pilot._xp >= 40) {
                this._sp += 127;
            } else if (_pilot._xp >= 30) {
                this._sp += 69;
            }

            this._sp += gear[_pilot._gear, _pilot._pieces];

            if (_pilot._stars == 1) {
                this._sp *= 1;
            } else if (_pilot._stars == 2) {
                this._sp *= 1.05;
            } else if (_pilot._stars == 3) {
                this._sp *= 1.1;
            } else if (_pilot._stars == 4) {
                this._sp *= 1.15;
            } else if (_pilot._stars == 5) {
                this._sp *= 1.25;
            } else if (_pilot._stars == 6) {
                this._sp *= 1.35;
            } else if (_pilot._stars == 7) {
                this._sp *= 1.5;
            }
            return this._sp;
        }

        public Ship() {
            _shipName = String.Empty;
            _stars = 0;
            _xp = 0;
            _basic = "0";
            _special = "0";
            _ultimate = "0";
            _pilot = new Character();
        }
        public Ship(String name, int stars, int xp, String basic, String special, String ultimate){
            /*
             public string _shipName;
        public int _stars;
        public int _xp;
        public string _basic;
        public string _special;
        public string _ultimate;
        public double _sp;
        public Character _pilot;
             */
            Name = name;
            Stars = stars;
            XP = xp;
            Basic = basic;
            Special = special;
            Ultimate = ultimate;
        }
    
        public void printShipInfo() {
            Console.WriteLine("Ship Name: "+ _shipName + " * " + _stars + " xp " + _xp + " pilot " + _pilot._name);
        }
    }
}
