﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace finalAssignment {
    internal class Squad {
        public Character _lead = new Character();
        public Character _SIC = new Character();    //Second in command
        public Character _PT = new Character();    //Power Trio
        public Character _Four = new Character();   //Hufflepuff
        public Character _FMB = new Character(); //Five Man Band

        private double _sp = 0;
        public double SP(){
            if (_lead != null) {
                this._sp += _lead._cp;
            }
            if (_SIC != null) { 
                this._sp += _SIC._cp;
            }
            if (_PT != null) { 
                this._sp += _PT._cp;
            }
            if (_Four != null) {
                this._sp += _Four._cp;
            }
            if (_FMB != null) {
                this._sp += _FMB._cp;
            }
            return this._sp;
        }

        public void printSquad() {
            _lead.printBasicInfo();
            _SIC.printBasicInfo();
            _PT.printBasicInfo();
            _Four.printBasicInfo();
            _FMB.printBasicInfo();
           
        }
        
        public Squad() {
            _lead = new Character();
            _SIC = new Character();
            _PT = new Character();
            _Four = new Character();
            _FMB = new Character();
            _sp = 0;

        } 
    }
}
