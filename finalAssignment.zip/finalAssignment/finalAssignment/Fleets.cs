﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finalAssignment {
    internal class Fleet {
        public Ship _capitalShip = new Ship();
        public Ship _startingOne = new Ship();
        public Ship _startingTwo = new Ship();
        public Ship _startingThree = new Ship();
        public Ship _reinforcementOne = new Ship();
        public Ship _reinforcementTwo = new Ship();
        public Ship _reinforcementThree = new Ship();
        public Ship _reinforcementFour = new Ship();
        private double _fp = 0;

        public double FP() {
            if (_capitalShip != null) {
                this._fp += _capitalShip._sp;
            }
            if (_startingOne != null) { 
                this._fp = _startingOne._sp;
            }
            if (_startingTwo != null) {
                this._fp = _startingTwo._sp;
            }
            if (_startingThree != null) {
                this._fp = _startingThree._sp;
            }
            if (_reinforcementOne != null) {
                this._fp = _reinforcementOne._sp;
            }
            if (_reinforcementTwo != null) {
                this._fp = _reinforcementTwo._sp;
            }
            if (_reinforcementThree != null) {
                this._fp = _reinforcementThree._sp;
            }
            if (_reinforcementFour != null) {
                this._fp = _reinforcementFour._sp;
            }
            return this._fp;
        }

        public void printFleet() {
            _capitalShip.printShipInfo();
            _startingOne.printShipInfo();
            _startingTwo.printShipInfo();
            _startingThree.printShipInfo();
            _reinforcementOne.printShipInfo();
            _reinforcementTwo.printShipInfo();
            _reinforcementThree.printShipInfo();
            _reinforcementFour.printShipInfo();
        }
        public Fleet() {
            _capitalShip = new Ship();
            _startingOne = new Ship();
            _startingTwo = new Ship();
            _startingThree = new Ship();
            _reinforcementOne = new Ship();
            _reinforcementTwo = new Ship();
            _reinforcementThree = new Ship();
            _reinforcementFour = new Ship();
            _fp = 0;
        }
    }
}
